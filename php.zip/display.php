<!doctype html>

<html>
<head>
 <title>COVID19 Diagnosis system Map</title>

</head>
<frameset cols="975px, *">{
	<frame src="left.php", scrolling="no", frameborder="0">
	<frame src="right.php", frameborder="0">
	}

</frameset>
<body>

</body>
</html>
